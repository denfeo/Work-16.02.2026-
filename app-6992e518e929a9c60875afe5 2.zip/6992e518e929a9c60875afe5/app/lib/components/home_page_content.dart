import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:app/globals/delivery_provider.dart';
import 'package:app/components/delivery_stats_card.dart';
import 'package:app/pages/payments_page.dart';
import 'package:app/components/recent_delivery_card.dart';

@NowaGenerated()
class HomePageContent extends StatelessWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const HomePageContent({super.key});

  Widget _buildHeaderIcon(
    BuildContext context,
    IconData icon, {
    bool hasBadge = false,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFF1E1E1E)),
      ),
      child: hasBadge
          ? Badge(
              backgroundColor: Theme.of(context).colorScheme.primary,
              label: const Text(
                '1',
                style: TextStyle(fontSize: 8, fontWeight: FontWeight.bold),
              ),
              child: Icon(icon, color: Colors.white, size: 24),
            )
          : Icon(icon, color: Colors.white, size: 24),
    );
  }

  Widget _buildStockItem(
    BuildContext context,
    IconData icon,
    String label,
    String value,
    Color color,
  ) {
    final theme = Theme.of(context);
    return Column(
      children: [
        Row(
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 4),
            Text(
              label,
              style: theme.textTheme.bodySmall?.copyWith(fontSize: 10),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: theme.textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildAnimatedItem({required Widget child, required int delay}) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: Duration(milliseconds: 600 + delay),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) => Opacity(
        opacity: value,
        child: Transform.translate(
          offset: Offset(0, 30 * (1 - value)),
          child: child,
        ),
      ),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final deliveryProvider = DeliveryProvider.of(context);
    final deliveries = deliveryProvider.deliveries;
    return RefreshIndicator(
      onRefresh: () async {
        await Future.delayed(const Duration(seconds: 1));
      },
      color: theme.colorScheme.primary,
      backgroundColor: theme.colorScheme.surface,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 24),
            _buildAnimatedItem(
              delay: 0,
              child: Row(
                children: [
                  Hero(
                    tag: 'avatar',
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: theme.colorScheme.primary,
                          width: 2,
                        ),
                      ),
                      child: const Padding(
                        padding: EdgeInsets.all(3),
                        child: CircleAvatar(
                          radius: 26,
                          backgroundImage: NetworkImage(
                            'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=200',
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Готов к доставке!',
                        style: theme.textTheme.bodySmall,
                      ),
                      Text(
                        'Оливер Беннет',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  _buildHeaderIcon(context, Icons.help_outline_rounded),
                  const SizedBox(width: 12),
                  _buildHeaderIcon(
                    context,
                    Icons.notifications_none_rounded,
                    hasBadge: true,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            _buildAnimatedItem(
              delay: 100,
              child: TextField(
                onChanged: (value) => deliveryProvider.setSearchQuery(value),
                decoration: InputDecoration(
                  hintText: 'Поиск по доставкам...',
                  prefixIcon: const Icon(
                    Icons.search_rounded,
                    color: Color(0xFF8E8E93),
                    size: 22,
                  ),
                  suffixIcon: Container(
                    margin: const EdgeInsets.all(8),
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.tune_rounded,
                      color: theme.colorScheme.primary,
                      size: 18,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 32),
            _buildAnimatedItem(
              delay: 200,
              child: GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 1.1,
                children: [
                  DeliveryStatsCard(
                    title: 'Всего товаров',
                    value: deliveryProvider.totalItems.toString(),
                    icon: const Icon(
                      Icons.inventory_2_rounded,
                      color: Colors.orange,
                    ),
                    backgroundColor: const Color(0xFF2B61FF),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const PaymentsPage(),
                      ),
                    ),
                    child: DeliveryStatsCard(
                      title: 'Завершено',
                      value: deliveryProvider.completedCount.toString(),
                      icon: const Icon(
                        Icons.check_circle_rounded,
                        color: Colors.green,
                      ),
                    ),
                  ),
                  DeliveryStatsCard(
                    title: 'В пути',
                    value: deliveryProvider.inProgressCount.toString(),
                    icon: const Icon(
                      Icons.local_shipping_rounded,
                      color: Colors.blue,
                    ),
                  ),
                  const DeliveryStatsCard(
                    title: 'Стеллажи',
                    value: '24',
                    icon: Icon(Icons.layers_rounded, color: Colors.purple),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            _buildAnimatedItem(
              delay: 300,
              child: Text('Обзор склада', style: theme.textTheme.titleLarge),
            ),
            const SizedBox(height: 16),
            _buildAnimatedItem(
              delay: 350,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: const Color(0xFF1E1E1E),
                    width: 1.5,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildStockItem(
                      context,
                      Icons.check_circle_rounded,
                      'В наличии',
                      '345',
                      Colors.green,
                    ),
                    _buildStockItem(
                      context,
                      Icons.info_rounded,
                      'Мало',
                      '15',
                      Colors.orange,
                    ),
                    _buildStockItem(
                      context,
                      Icons.cancel_rounded,
                      'Нет',
                      '6',
                      Colors.red,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 32),
            _buildAnimatedItem(
              delay: 400,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Недавние доставки', style: theme.textTheme.titleLarge),
                  TextButton(
                    onPressed: () {},
                    child: Text(
                      'Все',
                      style: TextStyle(
                        color: theme.colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            _buildAnimatedItem(
              delay: 450,
              child: deliveries.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 40),
                        child: Column(
                          children: [
                            const Icon(
                              Icons.inbox_rounded,
                              size: 48,
                              color: Colors.white24,
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'Нет активных доставок',
                              style: theme.textTheme.bodyMedium?.copyWith(
                                color: Colors.white38,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  : ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: deliveries.length > 5 ? 5 : deliveries.length,
                      itemBuilder: (context, index) {
                        final delivery = deliveries[index];
                        return Dismissible(
                          key: Key(delivery.id),
                          direction: DismissDirection.endToStart,
                          onDismissed: (direction) {
                            deliveryProvider.removeDelivery(delivery.id);
                          },
                          background: Container(
                            margin: const EdgeInsets.only(bottom: 12),
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            decoration: BoxDecoration(
                              color: Colors.red.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            alignment: Alignment.centerRight,
                            child: const Icon(
                              Icons.delete_outline_rounded,
                              color: Colors.red,
                            ),
                          ),
                          child: GestureDetector(
                            onTap: () {
                              if (delivery.status != 'Завершено') {
                                showModalBottomSheet(
                                  context: context,
                                  backgroundColor: const Color(0xFF0D0D0D),
                                  shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.vertical(
                                      top: Radius.circular(32),
                                    ),
                                  ),
                                  builder: (context) => Container(
                                    padding: const EdgeInsets.all(32),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          delivery.shopName,
                                          style: theme.textTheme.titleLarge,
                                        ),
                                        const SizedBox(height: 8),
                                        Text(
                                          'Товар: ${delivery.item}',
                                          style: theme.textTheme.bodyMedium,
                                        ),
                                        const SizedBox(height: 32),
                                        SizedBox(
                                          width: double.infinity,
                                          height: 56,
                                          child: ElevatedButton(
                                            onPressed: () {
                                              deliveryProvider.completeDelivery(
                                                delivery.id,
                                              );
                                              Navigator.pop(context);
                                            },
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: Colors.green,
                                              foregroundColor: Colors.white,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(16),
                                              ),
                                            ),
                                            child: const Text(
                                              'Отметить как выполнено',
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              }
                            },
                            child: RecentDeliveryCard(
                              shopName: delivery.shopName,
                              item: delivery.item,
                              status: delivery.status,
                              time: delivery.time,
                            ),
                          ),
                        );
                      },
                    ),
            ),
            const SizedBox(height: 120),
          ],
        ),
      ),
    );
  }
}
