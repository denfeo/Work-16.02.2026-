import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated()
class DeliveryStatsCard extends StatelessWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const DeliveryStatsCard({
    required this.title,
    required this.value,
    required this.icon,
    this.backgroundColor,
    this.isFullWidth = false,
    super.key,
  });

  final String title;

  final String value;

  final Widget icon;

  final Color? backgroundColor;

  final bool isFullWidth;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isPrimary = backgroundColor != null;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isPrimary ? backgroundColor : theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: isPrimary
              ? Colors.white.withValues(alpha: 0.1)
              : theme.cardTheme.shape is RoundedRectangleBorder
              ? (theme.cardTheme.shape as RoundedRectangleBorder).side.color
              : const Color(0xFF1E1E1E),
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: isPrimary
                      ? Colors.white.withValues(alpha: 0.15)
                      : theme.colorScheme.primary.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: IconTheme(
                  data: IconThemeData(
                    color: isPrimary ? Colors.white : theme.colorScheme.primary,
                    size: 20,
                  ),
                  child: icon,
                ),
              ),
              Icon(
                Icons.arrow_forward_ios_rounded,
                size: 14,
                color: isPrimary ? Colors.white54 : const Color(0xFF8E8E93),
              ),
            ],
          ),
          const Spacer(),
          Text(
            title,
            style: theme.textTheme.bodySmall?.copyWith(
              color: isPrimary ? Colors.white70 : const Color(0xFF8E8E93),
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w800,
              color: Colors.white,
              fontSize: 18,
            ),
          ),
        ],
      ),
    );
  }
}
