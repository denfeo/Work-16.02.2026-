import 'package:go_router/go_router.dart';
import 'package:app/pages/home_page.dart';
import 'package:app/pages/payments_page.dart';
import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated()
final GoRouter appRouter = GoRouter(
  initialLocation: '/home-page',
  routes: [
    GoRoute(path: '/home-page', builder: (context, state) => const HomePage()),
    GoRoute(
      path: '/payments',
      builder: (context, state) => const PaymentsPage(),
    ),
  ],
);
