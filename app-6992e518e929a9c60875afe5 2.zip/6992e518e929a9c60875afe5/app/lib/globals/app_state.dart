import 'package:flutter/material.dart';
import 'package:app/globals/themes.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:provider/provider.dart';

@NowaGenerated()
class AppState extends ChangeNotifier {
  AppState();

  factory AppState.of(BuildContext context, {bool listen = true}) {
    return Provider.of<AppState>(context, listen: listen);
  }

  ThemeData _theme = darkTheme;

  ThemeData get theme {
    return _theme;
  }

  bool get isDarkMode {
    return _theme.brightness == Brightness.dark;
  }

  void changeTheme(ThemeData theme) {
    _theme = theme;
    notifyListeners();
  }

  void toggleTheme() {
    changeTheme(isDarkMode ? lightTheme : darkTheme);
  }
}
