import 'package:flutter/material.dart';
import 'package:app/models/delivery.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:provider/provider.dart';

@NowaGenerated()
class DeliveryProvider extends ChangeNotifier {
  List<Delivery> _deliveries = [
    const Delivery(
      id: '1',
      shopName: 'Фреш Маркет, Какканад',
      item: 'Лапша',
      status: 'Завершено',
      time: '10:45 AM',
      quantity: 12,
    ),
    const Delivery(
      id: '2',
      shopName: 'Зеленая Лавка',
      item: 'Овощи',
      status: 'Завершено',
      time: '09:20 AM',
      quantity: 45,
    ),
    const Delivery(
      id: '3',
      shopName: 'Супермаркет Центр',
      item: 'Напитки',
      status: 'В пути',
      time: '12:00 PM',
      quantity: 100,
    ),
  ];

  String _searchQuery = '';

  List<Delivery> get deliveries {
    if (_searchQuery.isEmpty) {
      return _deliveries;
    }
    return _deliveries
        .where(
          (d) =>
              d.shopName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
              d.item.toLowerCase().contains(_searchQuery.toLowerCase()),
        )
        .toList();
  }

  int get completedCount {
    return _deliveries.where((d) => d.status == 'Завершено').length;
  }

  int get inProgressCount {
    return _deliveries.where((d) => d.status != 'Завершено').length;
  }

  int get totalItems {
    return _deliveries.fold(0, (sum, d) => sum + d.quantity);
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void addDelivery(Delivery delivery) {
    _deliveries.insert(0, delivery);
    notifyListeners();
  }

  void completeDelivery(String id) {
    final index = _deliveries.indexWhere((d) => d.id == id);
    if (index != -1) {
      final d = _deliveries[index];
      _deliveries[index] = Delivery(
        id: d.id,
        shopName: d.shopName,
        item: d.item,
        status: 'Завершено',
        time: d.time,
        quantity: d.quantity,
        location: d.location,
      );
      notifyListeners();
    }
  }

  void removeDelivery(String id) {
    _deliveries.removeWhere((d) => d.id == id);
    notifyListeners();
  }

  static DeliveryProvider of(BuildContext context, {bool listen = true}) {
    return Provider.of<DeliveryProvider>(context, listen: listen);
  }
}
