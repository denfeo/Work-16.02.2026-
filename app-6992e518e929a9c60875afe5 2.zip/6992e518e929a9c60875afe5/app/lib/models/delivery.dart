import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated()
class Delivery {
  const Delivery({
    required this.id,
    required this.shopName,
    required this.item,
    required this.status,
    required this.time,
    required this.quantity,
    this.location = '',
  });

  factory Delivery.fromJson(Map<String, dynamic> json) {
    return Delivery(
      id: json['id'] as String,
      shopName: json['shopName'] as String,
      item: json['item'] as String,
      status: json['status'] as String,
      time: json['time'] as String,
      quantity: json['quantity'] as int,
      location: json['location'] as String? ?? '',
    );
  }

  final String id;

  final String shopName;

  final String item;

  final String status;

  final String time;

  final int quantity;

  final String location;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'shopName': shopName,
      'item': item,
      'status': status,
      'time': time,
      'quantity': quantity,
      'location': location,
    };
  }
}
