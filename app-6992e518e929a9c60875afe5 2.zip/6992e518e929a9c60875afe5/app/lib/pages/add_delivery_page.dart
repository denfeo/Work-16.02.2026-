import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:app/models/delivery.dart';
import 'package:app/globals/delivery_provider.dart';

@NowaGenerated()
class AddDeliveryPage extends StatefulWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const AddDeliveryPage({super.key});

  @override
  State<AddDeliveryPage> createState() {
    return _AddDeliveryPageState();
  }
}

@NowaGenerated()
class _AddDeliveryPageState extends State<AddDeliveryPage> {
  final TextEditingController _shopController = TextEditingController();

  final TextEditingController _itemController = TextEditingController();

  final TextEditingController _quantityController = TextEditingController();

  String _selectedPriority = 'Средний';

  @override
  void dispose() {
    _shopController.dispose();
    _itemController.dispose();
    _quantityController.dispose();
    super.dispose();
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: Color(0xFF2B61FF),
        fontSize: 12,
        fontWeight: FontWeight.bold,
        letterSpacing: 1.5,
      ),
    );
  }

  Widget _buildModernTextField({
    TextEditingController? controller,
    required String hint,
    required IconData icon,
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        prefixIcon: Icon(icon, color: Colors.white24, size: 20),
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white24, fontSize: 15),
        filled: true,
        fillColor: Colors.white.withValues(alpha: 0.04),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 20,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: BorderSide(color: Colors.white.withValues(alpha: 0.05)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: BorderSide(color: Colors.white.withValues(alpha: 0.05)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: const BorderSide(color: Color(0xFF2B61FF)),
        ),
      ),
    );
  }

  void _createDelivery() {
    if (_shopController.text.isEmpty || _itemController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Пожалуйста, заполните все обязательные поля'),
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }
    final newDelivery = Delivery(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      shopName: _shopController.text,
      item: _itemController.text,
      status: 'В пути',
      time: 'Только что',
      quantity: int.tryParse(_quantityController.text) ?? 1,
    );
    DeliveryProvider.of(context, listen: false).addDelivery(newDelivery);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Row(
          children: const [
            Icon(Icons.check_circle, color: Colors.white),
            SizedBox(width: 12),
            Text('Доставка успешно создана!'),
          ],
        ),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
      ),
    );
    Navigator.pop(context);
  }

  Widget _buildPrioritySelector() {
    final priorities = ['Низкий', 'Средний', 'Высокий'];
    return Row(
      children: priorities.map((p) {
        final isSelected = _selectedPriority == p;
        return Padding(
          padding: const EdgeInsets.only(right: 8),
          child: ChoiceChip(
            label: Text(p),
            selected: isSelected,
            onSelected: (selected) {
              if (selected) {
                setState(() => _selectedPriority = p);
              }
            },
            selectedColor: const Color(0xFF2B61FF),
            backgroundColor: Colors.white.withValues(alpha: 0.05),
            labelStyle: TextStyle(
              color: isSelected ? Colors.white : Colors.white60,
              fontSize: 13,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            side: BorderSide.none,
          ),
        );
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Новая доставка',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('ОБЪЕКТ НАЗНАЧЕНИЯ'),
            const SizedBox(height: 16),
            _buildModernTextField(
              controller: _shopController,
              hint: 'Введите адрес магазина или ID',
              icon: Icons.storefront,
            ),
            const SizedBox(height: 32),
            _buildSectionHeader('ДЕТАЛИ ТОВАРА'),
            const SizedBox(height: 16),
            _buildModernTextField(
              controller: _itemController,
              hint: 'Название товара или SKU',
              icon: Icons.inventory_2_outlined,
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildModernTextField(
                    controller: _quantityController,
                    hint: 'Кол-во',
                    icon: Icons.format_list_numbered,
                    keyboardType: TextInputType.number,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Container(
                    height: 64,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.04),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.05),
                      ),
                    ),
                    child: const Row(
                      children: const [
                        Icon(
                          Icons.timer_outlined,
                          color: Colors.white24,
                          size: 20,
                        ),
                        SizedBox(width: 12),
                        Text(
                          'Срочно',
                          style: TextStyle(color: Colors.white24, fontSize: 15),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
            _buildSectionHeader('ПРИОРИТЕТ'),
            const SizedBox(height: 16),
            _buildPrioritySelector(),
            const SizedBox(height: 40),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF2B61FF).withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: const Color(0xFF2B61FF).withValues(alpha: 0.1),
                ),
              ),
              child: const Row(
                children: const [
                  Icon(Icons.info_outline, color: Color(0xFF2B61FF)),
                  SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      'После создания доставка будет автоматически добавлена в ваш текущий маршрут.',
                      style: TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
            SizedBox(
              width: double.infinity,
              height: 64,
              child: ElevatedButton(
                onPressed: _createDelivery,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2B61FF),
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(22),
                  ),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Text(
                      'Создать доставку',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(width: 12),
                    Icon(Icons.arrow_forward, size: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
