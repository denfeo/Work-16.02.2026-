import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:app/components/transaction_item.dart';

@NowaGenerated()
class PaymentsPage extends StatelessWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const PaymentsPage({super.key});

  Widget _buildFilterTab(BuildContext context, String title, bool isSelected) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: isSelected
            ? Theme.of(context).colorScheme.primary
            : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        title,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.white24,
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          fontSize: 13,
        ),
      ),
    );
  }

  Widget _buildAnimatedItem({required Widget child, required int delay}) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: Duration(milliseconds: 600 + delay),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) => Opacity(
        opacity: value,
        child: Transform.translate(
          offset: Offset(0, 20 * (1 - value)),
          child: child,
        ),
      ),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, size: 24),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Платежи',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        centerTitle: false,
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 24),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.green.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.green.withValues(alpha: 0.2)),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.account_balance_wallet_rounded,
                  color: Colors.green,
                  size: 16,
                ),
                const SizedBox(width: 8),
                Text(
                  'Всего: ₽10,326.00',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 16),
            _buildAnimatedItem(
              delay: 0,
              child: SizedBox(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  physics: const BouncingScrollPhysics(),
                  children: ['Май', 'Июнь', 'Июль', 'Август', 'Сентябрь'].map((
                    month,
                  ) {
                    final isSelected = month == 'Июль';
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: const EdgeInsets.only(right: 28),
                      padding: isSelected
                          ? const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 4,
                            )
                          : null,
                      decoration: isSelected
                          ? BoxDecoration(
                              color: theme.colorScheme.primary.withValues(
                                alpha: 0.2,
                              ),
                              borderRadius: BorderRadius.circular(20),
                            )
                          : null,
                      alignment: Alignment.center,
                      child: Text(
                        month,
                        style: TextStyle(
                          color: isSelected
                              ? theme.colorScheme.primary
                              : const Color(0xFF8E8E93),
                          fontWeight: isSelected
                              ? FontWeight.bold
                              : FontWeight.normal,
                          fontSize: 15,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
            const SizedBox(height: 24),
            _buildAnimatedItem(
              delay: 100,
              child: SizedBox(
                height: 90,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  physics: const BouncingScrollPhysics(),
                  itemCount: 7,
                  itemBuilder: (context, index) {
                    final days = ['16', '17', '18', '19', '20', '21', '22'];
                    final weeks = ['Ср', 'Чт', 'Пт', 'Сб', 'Вс', 'Пн', 'Вт'];
                    final isSelected = index == 1;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      width: 65,
                      margin: const EdgeInsets.only(right: 14),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? theme.colorScheme.primary
                            : const Color(0xFF121212),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: isSelected
                              ? theme.colorScheme.primary.withValues(alpha: 0.5)
                              : const Color(0xFF1E1E1E),
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            days[index],
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: isSelected
                                  ? FontWeight.bold
                                  : FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            weeks[index],
                            style: TextStyle(
                              color: isSelected
                                  ? Colors.white70
                                  : const Color(0xFF8E8E93),
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 32),
            _buildAnimatedItem(
              delay: 200,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF121212),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF1E1E1E)),
                  ),
                  child: Row(
                    children: [
                      Expanded(child: _buildFilterTab(context, 'Все', true)),
                      Expanded(
                        child: _buildFilterTab(context, 'Неделя', false),
                      ),
                      Expanded(child: _buildFilterTab(context, 'Месяц', false)),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 32),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                physics: const BouncingScrollPhysics(),
                children: [
                  _buildAnimatedItem(
                    delay: 300,
                    child: const TransactionItem(
                      shopName: 'Фреш Маркет, Какканад',
                      date: '17 июля, 2025 • 10:45 AM',
                      amount: '2,359.00',
                      status: 'Получено',
                      transactionId: 'ID Транзакции',
                    ),
                  ),
                  _buildAnimatedItem(
                    delay: 400,
                    child: const TransactionItem(
                      shopName: 'Фреш Маркет, Какканад',
                      date: '17 июля, 2025 • 10:45 AM',
                      amount: '4,500.00',
                      status: 'Ожидание',
                      transactionId: 'ID Транзакции',
                    ),
                  ),
                  _buildAnimatedItem(
                    delay: 500,
                    child: const TransactionItem(
                      shopName: 'Фреш Маркет, Какканад',
                      date: '17 июля, 2025 • 10:45 AM',
                      amount: '3,000.00',
                      status: 'Получено',
                      transactionId: 'ID Транзакции',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
